<template>
    <div class="recruitDetail-container">

    </div>
</template>

<script>
    export default {
        name: 'recruitDetail',
        data() {
            return {}
        },
        mounted() {
        },
        methods: {},
        computed: {},
        components: {}
    }
</script>
<style scoped lang="scss">

</style>
