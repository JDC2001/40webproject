<template>
    <div class="companyDetail-container">

    </div>
</template>

<script>
    export default {
        name: 'companyDetail',
        data() {
            return {}
        },
        mounted() {
        },
        methods: {},
        computed: {},
        components: {}
    }
</script>
<style scoped lang="scss">

</style>
