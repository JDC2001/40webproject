package com.nowcoder.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by 周杰伦 on 2018/5/3.
 */
@Controller
public class UserController {
//    @RequestMapping("t1")
//    @ResponseBody
//    public Model test1(Model model) {
//        model.addAttribute("a","b");
//        return model;
//    }
//
//    @RequestMapping("t2")
//    @ResponseBody
//    public ModelAndView test2(ModelAndView modelAndView) {
//        modelAndView.addObject(Arrays.asList(new String[]{"a","b","c"}));
//        return modelAndView;
//    }

//    @RequestMapping("t3")
//    @ResponseBody
//    public Map test3() {
//        Map map = new HashMap();
//        map.put("a","b");
//        return map;
//    }
}
