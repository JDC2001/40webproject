package com.nowcoder.service;

import org.springframework.stereotype.Service;

/**
 * Created by 周杰伦 on 2018/5/2.
 */
@Service
public class ToutiaoService {
    public String say() {
        return "this is from toutiaoService";
    }
}
